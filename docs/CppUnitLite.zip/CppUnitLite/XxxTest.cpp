#include "TestHarness.h"

// Rename this file to match the functionality under test. E.g., StringTest.
// Add tests and CHECKs as required
TEST(char, strings)
{
    CHECK_EQUAL(1, 1);
}
